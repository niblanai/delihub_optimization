-- ════════════════════════════════════════════════════════════════════════════
-- Run this against the .db file the APP actually opens (not the copy in build/).
-- Anything missing here is why the sidebar went empty.
--
--   sqlite3 path/to/your.db < check_schema.sql
-- ════════════════════════════════════════════════════════════════════════════

.headers on
.mode column

-- 1. Do the Roles permission columns exist?
--    Every name in the app's SELECT must appear here, or the whole query fails
--    and every permission reads as false.
PRAGMA table_info(Roles);

-- 2. Do the Users columns exist?
PRAGMA table_info(Users);

-- 3. Does the Attendance table exist?
SELECT name FROM sqlite_master WHERE type='table' AND name='Attendance';

-- 4. What do the roles actually look like?
SELECT Id, Name, CanManageUsers, CanAccessSettings, CanViewReports, canDeleteFromPOS
FROM Roles;

-- 5. Which users have a barcode?
SELECT Id, Username, Name, RoleId,
       COALESCE(FingerprintBarcode, '(none)') AS Barcode
FROM Users;


-- ════════════════════════════════════════════════════════════════════════════
-- MANUAL REPAIR (only if you want to fix the file by hand instead of letting
-- the app's new ensureRoleColumns()/ensureUserColumns() do it on next launch).
-- Each ALTER errors harmlessly if the column already exists.
-- ════════════════════════════════════════════════════════════════════════════

-- ALTER TABLE Roles ADD COLUMN canDeleteFromPOS   INTEGER DEFAULT 0;
-- ALTER TABLE Roles ADD COLUMN CanAccessDashboard INTEGER DEFAULT 1;
-- ALTER TABLE Roles ADD COLUMN CanManagePurchases INTEGER DEFAULT 0;
-- ALTER TABLE Roles ADD COLUMN CanAccessPOS       INTEGER DEFAULT 0;
-- ALTER TABLE Roles ADD COLUMN CanManageRegister  INTEGER DEFAULT 0;
-- ALTER TABLE Roles ADD COLUMN CanManageExpenses  INTEGER DEFAULT 0;
-- ALTER TABLE Roles ADD COLUMN CanManageInventory INTEGER DEFAULT 0;

-- ALTER TABLE Users ADD COLUMN PhotoPath          TEXT DEFAULT '';
-- ALTER TABLE Users ADD COLUMN FingerprintBarcode TEXT DEFAULT '';
-- ALTER TABLE Users ADD COLUMN HourlyRate         REAL DEFAULT 0;
-- ALTER TABLE Users ADD COLUMN WeeklyOffDays      INTEGER DEFAULT 0;

-- Give the admin role its permissions back:
-- UPDATE Roles SET CanManageUsers=1, CanAccessSettings=1, CanViewReports=1,
--                  canDeleteFromPOS=1, CanAccessDashboard=1
-- WHERE Id = (SELECT RoleId FROM Users WHERE Username='admin');
