# خطوات الدمج

## 1. الملفات الجديدة

```
src/services/barcode_generator.h
src/services/barcode_generator.cpp
src/ui/id_card_renderer.h
src/ui/id_card_renderer.cpp
```

## 2. تعديل `users_page.h`

أضف في أول الملف:

```cpp
#include "ui/id_card_renderer.h"
```

وأضف في قسم `private:` داخل `class UsersPage`:

```cpp
    bool buildCardData(int userId, IdCardRenderer::CardData& out,
                       QString* error = nullptr) const;
```

تأكد كمان إن `<QPrinter>` و `<QPrintDialog>` متضمنين (كانوا مستخدمين أصلاً).

## 3. CMakeLists.txt

```cmake
target_sources(YourApp PRIVATE
    src/services/barcode_generator.cpp
    src/ui/id_card_renderer.cpp
)

# لازم موديول الطباعة
find_package(Qt6 REQUIRED COMPONENTS Widgets PrintSupport)
target_link_libraries(YourApp PRIVATE Qt6::Widgets Qt6::PrintSupport)
```

كده التطبيق هيشتغل **من غير أي مكتبة خارجية** — الـ encoder الداخلي بيعمل Code 128 صح.

## 4. تفعيل ZXing-C++ (اختياري)

### التثبيت

vcpkg:
```
vcpkg install zxing-cpp
```

أو build من المصدر:
```bash
git clone https://github.com/zxing-cpp/zxing-cpp.git
cd zxing-cpp && cmake -B build -DZXING_EXAMPLES=OFF -DZXING_BLACKBOX_TESTS=OFF
cmake --build build --config Release
cmake --install build
```

### الربط

```cmake
find_package(ZXing QUIET)
if(ZXing_FOUND)
    target_link_libraries(YourApp PRIVATE ZXing::ZXing)
    target_compile_definitions(YourApp PRIVATE ZXING_AVAILABLE)
endif()
```

مجرد ما تتعرّف `ZXING_AVAILABLE` الملف بيستخدم ZXing تلقائياً، ولو فشل لأي سبب
بيرجع للـ encoder الداخلي — مفيش كود تاني محتاج يتغير.

**ملاحظة:** في ZXing-C++ 2.2+ الـ `MultiFormatWriter` اتعلّم عليه deprecated لكنه
لسه شغال. لو استخدمت 3.x وطلع warning، بدّل `encodeZXing()` بالـ API الجديد:

```cpp
auto barcode = ZXing::CreateBarcodeFromText(text.toStdString(),
                                            ZXing::BarcodeFormat::Code128);
```

## 5. ملاحظات عن القراءة بالماسح (scanner)

- الباركود مرسوم بعرض module ثابت بالبكسل (مفيش scaling/تنعيم) — ده أهم عامل
  في إن الماسح يقراه.
- اطبع بـ 300 DPI على الأقل. الكود بيستخدم `printer.resolution()` تلقائياً.
- الـ quiet zone (الهامش الفاضي على الجنبين) = 10 modules زي ما المواصفة بتطلب.
  متقصّهاش لما تقص الكارت.
- الفورمات الحالي `FP-1758123456-4821` طوله 18 حرف = 233 module. لو حبيت باركود
  أقصر وأوضح، خلّي الكود أرقام بس (مثلاً 10 أرقام) — Code 128 بيضغط الأرقام
  لنص الحجم تقريباً.
