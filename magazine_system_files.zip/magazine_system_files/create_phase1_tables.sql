-- Create Phase 1 tables for SQLite

-- 1. Suppliers
CREATE TABLE IF NOT EXISTS Suppliers (
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    Name TEXT NOT NULL,
    Phone TEXT,
    Email TEXT,
    Address TEXT,
    Status TEXT DEFAULT 'Active',
    Notes TEXT
);

-- 2. RegisterSessions
CREATE TABLE IF NOT EXISTS RegisterSessions (
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    UserId INTEGER NOT NULL,
    OpeningCash REAL DEFAULT 0,
    ClosingCash REAL DEFAULT 0,
    OpenedAt TEXT NOT NULL,
    ClosedAt TEXT,
    Status TEXT DEFAULT 'Open',
    FOREIGN KEY(UserId) REFERENCES Users(Id)
);

-- 3. CashMovements
CREATE TABLE IF NOT EXISTS CashMovements (
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    RegisterSessionId INTEGER NOT NULL,
    Type TEXT NOT NULL,
    Amount REAL NOT NULL,
    Reason TEXT,
    DateTime TEXT NOT NULL,
    UserId INTEGER,
    FOREIGN KEY(RegisterSessionId) REFERENCES RegisterSessions(Id)
);

-- 4. ExpenseCategories
CREATE TABLE IF NOT EXISTS ExpenseCategories (
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    Name TEXT NOT NULL UNIQUE,
    Description TEXT
);

-- 5. Expenses
CREATE TABLE IF NOT EXISTS Expenses (
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    CategoryId INTEGER,
    Amount REAL NOT NULL,
    Description TEXT,
    Date TEXT NOT NULL,
    UserId INTEGER,
    RegisterSessionId INTEGER,
    FOREIGN KEY(CategoryId) REFERENCES ExpenseCategories(Id),
    FOREIGN KEY(RegisterSessionId) REFERENCES RegisterSessions(Id)
);

-- 6. PurchaseInvoices
CREATE TABLE IF NOT EXISTS PurchaseInvoices (
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    InvoiceNumber TEXT NOT NULL UNIQUE,
    SupplierId INTEGER NOT NULL,
    Date TEXT NOT NULL,
    TotalAmount REAL DEFAULT 0,
    PaidAmount REAL DEFAULT 0,
    Status TEXT DEFAULT 'Draft',
    Notes TEXT,
    UserId INTEGER,
    FOREIGN KEY(SupplierId) REFERENCES Suppliers(Id)
);

-- 7. PurchaseInvoiceItems
CREATE TABLE IF NOT EXISTS PurchaseInvoiceItems (
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    InvoiceId INTEGER NOT NULL,
    ProductId INTEGER NOT NULL,
    Quantity REAL NOT NULL,
    UnitCost REAL NOT NULL,
    Total REAL NOT NULL,
    FOREIGN KEY(InvoiceId) REFERENCES PurchaseInvoices(Id),
    FOREIGN KEY(ProductId) REFERENCES Products(Id)
);

-- 8. StockMovements
CREATE TABLE IF NOT EXISTS StockMovements (
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    ProductId INTEGER NOT NULL,
    Type TEXT NOT NULL,
    Quantity REAL NOT NULL,
    DateTime TEXT NOT NULL,
    ReferenceId INTEGER,
    ReferenceType TEXT,
    Notes TEXT,
    UserId INTEGER,
    FOREIGN KEY(ProductId) REFERENCES Products(Id)
);

-- 9. StockCounts
CREATE TABLE IF NOT EXISTS StockCounts (
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    CountNumber TEXT NOT NULL UNIQUE,
    Date TEXT NOT NULL,
    Status TEXT DEFAULT 'Draft',
    Notes TEXT,
    UserId INTEGER
);

-- 10. StockCountItems
CREATE TABLE IF NOT EXISTS StockCountItems (
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    CountId INTEGER NOT NULL,
    ProductId INTEGER NOT NULL,
    SystemQty REAL NOT NULL,
    ActualQty REAL NOT NULL,
    Difference REAL NOT NULL,
    FOREIGN KEY(CountId) REFERENCES StockCounts(Id),
    FOREIGN KEY(ProductId) REFERENCES Products(Id)
);

-- 11. ProductCostHistory
CREATE TABLE IF NOT EXISTS ProductCostHistory (
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    ProductId INTEGER NOT NULL,
    Cost REAL NOT NULL,
    ChangeDate TEXT NOT NULL,
    PurchaseInvoiceId INTEGER,
    FOREIGN KEY(ProductId) REFERENCES Products(Id),
    FOREIGN KEY(PurchaseInvoiceId) REFERENCES PurchaseInvoices(Id)
);

-- 12. TaxSettings
CREATE TABLE IF NOT EXISTS TaxSettings (
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    TaxRate REAL DEFAULT 0,
    IncludeInPrice INTEGER DEFAULT 0
);

-- 13. Promotions
CREATE TABLE IF NOT EXISTS Promotions (
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    Title TEXT NOT NULL,
    Description TEXT,
    Type TEXT DEFAULT 'Percentage',
    DiscountValue REAL DEFAULT 0,
    StartDate TEXT NOT NULL,
    EndDate TEXT NOT NULL,
    Status TEXT DEFAULT 'Active',
    ImagePath TEXT,
    ProductId INTEGER DEFAULT 0,
    CategoryId INTEGER DEFAULT 0,
    MinPurchaseAmount REAL DEFAULT 0
);

-- 14. ProductSuppliers
CREATE TABLE IF NOT EXISTS ProductSuppliers (
    ProductId INTEGER NOT NULL,
    SupplierId INTEGER NOT NULL,
    PurchasePrice REAL DEFAULT 0,
    IsPreferred INTEGER DEFAULT 0,
    LastPurchaseDate TEXT,
    PRIMARY KEY(ProductId, SupplierId),
    FOREIGN KEY(ProductId) REFERENCES Products(Id),
    FOREIGN KEY(SupplierId) REFERENCES Suppliers(Id)
);

-- Insert default tax settings if not exists
INSERT OR IGNORE INTO TaxSettings (Id, TaxRate, IncludeInPrice) VALUES (1, 0.0, 0);

-- Add CostPrice and UnitLabel to Products if not exists
-- (SQLite doesn't support IF NOT EXISTS for columns, so we use a different approach)

-- Verify tables
SELECT name FROM sqlite_master WHERE type='table' AND name LIKE '%Session%' OR name LIKE '%Supplier%' OR name LIKE '%Expense%' OR name LIKE '%Stock%' OR name LIKE '%Purchase%';


-- 14. PromotionProducts junction table (Many-to-Many: Promotion - Products)
CREATE TABLE IF NOT EXISTS PromotionProducts (
    PromotionId INTEGER NOT NULL,
    ProductId INTEGER NOT NULL,
    MagazinePrice REAL DEFAULT 0,
    PRIMARY KEY (PromotionId, ProductId),
    FOREIGN KEY (PromotionId) REFERENCES Promotions(Id) ON DELETE CASCADE,
    FOREIGN KEY (ProductId) REFERENCES Products(Id) ON DELETE CASCADE
);
