-- Create Promotions table
CREATE TABLE IF NOT EXISTS Promotions (
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    Title TEXT NOT NULL,
    Description TEXT,
    Type INTEGER DEFAULT 0,
    DiscountValue REAL DEFAULT 0,
    StartDate DATETIME,
    EndDate DATETIME,
    Status INTEGER DEFAULT 0,
    ImagePath TEXT,
    ProductId INTEGER,
    CategoryId INTEGER,
    MinPurchaseAmount REAL DEFAULT 0
);

-- Create PromotionProducts junction table
CREATE TABLE IF NOT EXISTS PromotionProducts (
    PromotionId INTEGER NOT NULL,
    ProductId INTEGER NOT NULL,
    MagazinePrice REAL DEFAULT 0,
    PRIMARY KEY (PromotionId, ProductId),
    FOREIGN KEY (PromotionId) REFERENCES Promotions(Id) ON DELETE CASCADE,
    FOREIGN KEY (ProductId) REFERENCES Products(Id) ON DELETE CASCADE
);

-- Verify tables created
SELECT 'Promotions table created' as Status;
SELECT 'PromotionProducts table created' as Status;
