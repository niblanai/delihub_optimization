-- Check if promotion exists
SELECT 'Promotions Table:' as Info;
SELECT Id, Title, Status, StartDate, EndDate FROM Promotions;

SELECT '';
SELECT 'PromotionProducts Table:' as Info;
SELECT pp.PromotionId, pp.ProductId, pp.MagazinePrice, p.Name as ProductName
FROM PromotionProducts pp
JOIN Products p ON pp.ProductId = p.Id;

SELECT '';
SELECT 'Active Promotions with Products:' as Info;
SELECT 
    prom.Id as PromotionId,
    prom.Title,
    prom.Status,
    datetime(prom.StartDate) as StartDate,
    datetime(prom.EndDate) as EndDate,
    datetime('now') as CurrentTime,
    pp.ProductId,
    prod.Name as ProductName,
    prod.Price as OriginalPrice,
    pp.MagazinePrice,
    CASE 
        WHEN prom.Status = 1 THEN 'Active'
        ELSE 'Not Active'
    END as StatusText,
    CASE
        WHEN datetime('now') >= datetime(prom.StartDate) AND datetime('now') <= datetime(prom.EndDate) THEN 'In Date Range'
        ELSE 'Out of Date Range'
    END as DateStatus
FROM Promotions prom
JOIN PromotionProducts pp ON pp.PromotionId = prom.Id
JOIN Products prod ON pp.ProductId = prod.Id
WHERE prom.Status = 1;
