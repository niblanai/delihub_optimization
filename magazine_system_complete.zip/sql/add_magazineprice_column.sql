-- Add MagazinePrice column to PromotionProducts table if not exists
-- This is safe to run multiple times

-- For SQLite
ALTER TABLE PromotionProducts ADD COLUMN MagazinePrice REAL DEFAULT 0;

-- Verify
SELECT * FROM PromotionProducts LIMIT 1;
