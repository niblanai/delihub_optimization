#ifndef CONFIG_MANAGER_H
#define CONFIG_MANAGER_H

#include <QString>
#include <QMap>
#include <memory>

// Forward declaration — QSettings only needed in .cpp
class QSettings;

class ConfigManager {
public:
    static ConfigManager& instance();

    void init(const QString& filePath);

    // Getters
    QString databaseType() const;
    QString odbcConnectionString() const;
    QString sqlitePath() const;
    int     branchId() const;
    QString branchName() const;
    QString currencySymbol() const;
    QString theme() const;
    QString language() const;

    // Company / Invoice settings
    QString companyName() const;
    QString companyAddress() const;
    QString companyPhone() const;
    QString companyTaxNumber() const;
    QString invoiceLogoPath() const;
    int     nextInvoiceNumber() const;
    void    incrementInvoiceNumber();
    
    // Tax settings
    double  taxRate() const;
    void    setTaxRate(double rate);

    void setCompanyName(const QString& v);
    void setCompanyAddress(const QString& v);
    void setCompanyPhone(const QString& v);
    void setCompanyTaxNumber(const QString& v);
    void setInvoiceLogoPath(const QString& v);

    // Auto-backup settings
    QString autoBackupTime()     const;
    QString autoBackupDir()      const;
    QString lastAutoBackupDate() const;
    void setLastAutoBackupDate(const QString& d);
    void setAutoBackupTime(const QString& t);
    void setAutoBackupDir(const QString& d);

    // Notes board background
    // bgMode: "solid" (default — follows theme) or "image"
    QString notesBgMode()       const;
    QString notesBgImagePath()  const;
    void setNotesBgMode(const QString& mode);
    void setNotesBgImagePath(const QString& path);

    // POS deletion protection
    bool requireAuthForPOSDeletion() const;
    void setRequireAuthForPOSDeletion(bool enabled);

    // Receipt template designer
    // Templates are stored per paper width so switching 80mm <-> 58mm doesn't
    // clobber the other size's layout.
    QString receiptTemplateJson(int paperWidthMm) const;
    void    setReceiptTemplateJson(int paperWidthMm, const QString& json);
    int     receiptPaperWidthMm() const;          // last-selected paper size
    void    setReceiptPaperWidthMm(int mm);
    QString receiptPrinterName() const;           // empty = show print dialog
    void    setReceiptPrinterName(const QString& name);

    // Generic key-value read (for reminder state tracking)
    QString value(const QString& key, const QString& defaultVal) const;
    // Allow external code to set transient in-memory overrides (e.g. reminder tracking)
    void setOverride(const QString& key, const QString& val) {
        m_overrides[key] = val;
    }

    // Setters (work even without init(), using in-memory overrides)
    void setDatabaseType(const QString& type);
    void setOdbcConnectionString(const QString& connStr);
    void setSqlitePath(const QString& path);
    void setBranchId(int id);
    void setBranchName(const QString& name);
    void setCurrencySymbol(const QString& symbol);
    void setTheme(const QString& theme);
    void setLanguage(const QString& lang);

    QString configFilePath() const { return m_filePath; }

private:
    ConfigManager() = default;
    ~ConfigManager() = default;
    ConfigManager(const ConfigManager&) = delete;
    ConfigManager& operator=(const ConfigManager&) = delete;

    QString m_filePath;
    std::unique_ptr<QSettings> m_settings;

    // In-memory overrides (used even without a settings file)
    QMap<QString, QString> m_overrides;
};

#endif // CONFIG_MANAGER_H
