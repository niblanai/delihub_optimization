#include "config_manager.h"
#include "logger.h"
#include <QSettings>
#include <QFile>
#include <QDir>

ConfigManager& ConfigManager::instance() {
    static ConfigManager inst;
    return inst;
}

// Private helper: override map takes precedence over QSettings
QString ConfigManager::value(const QString& key, const QString& defaultVal) const {
    if (m_overrides.contains(key))
        return m_overrides.value(key);
    if (m_settings)
        return m_settings->value(key, defaultVal).toString();
    return defaultVal;
}

void ConfigManager::init(const QString& filePath) {
    m_filePath = filePath;
    m_settings = std::make_unique<QSettings>(filePath, QSettings::IniFormat);
    Logger::instance().info("Configuration loaded from " + filePath);
}

QString ConfigManager::databaseType() const {
    return value("Database/Type", "SQLite");
}

QString ConfigManager::odbcConnectionString() const {
    return value("Database/ConnectionString", "");
}

QString ConfigManager::sqlitePath() const {
    return value("Database/SQLitePath", "delivery_system.db");
}

int ConfigManager::branchId() const {
    bool ok = false;
    int v = value("Branch/ID", "1").toInt(&ok);
    return ok ? v : 1;
}

QString ConfigManager::branchName() const {
    return value("Branch/Name", "Main Branch");
}

QString ConfigManager::currencySymbol() const {
    QString v = value("System/Currency", "£");
    // If empty or still the old $ default, return £
    return (v.isEmpty() || v == "$") ? "£" : v;
}

// Setters: write to override map (immediate effect) AND persist to QSettings if loaded
void ConfigManager::setDatabaseType(const QString& type) {
    m_overrides["Database/Type"] = type;
    if (m_settings) m_settings->setValue("Database/Type", type);
    Logger::instance().info("Config: Database Type = " + type);
}

void ConfigManager::setOdbcConnectionString(const QString& connStr) {
    m_overrides["Database/ConnectionString"] = connStr;
    if (m_settings) m_settings->setValue("Database/ConnectionString", connStr);
}

void ConfigManager::setSqlitePath(const QString& path) {
    m_overrides["Database/SQLitePath"] = path;
    if (m_settings) m_settings->setValue("Database/SQLitePath", path);
    Logger::instance().info("Config: SQLite Path = " + path);
}

void ConfigManager::setBranchId(int id) {
    m_overrides["Branch/ID"] = QString::number(id);
    if (m_settings) m_settings->setValue("Branch/ID", id);
}

void ConfigManager::setBranchName(const QString& name) {
    m_overrides["Branch/Name"] = name;
    if (m_settings) m_settings->setValue("Branch/Name", name);
}

void ConfigManager::setCurrencySymbol(const QString& symbol) {
    m_overrides["System/Currency"] = symbol;
    if (m_settings) m_settings->setValue("System/Currency", symbol);
}

QString ConfigManager::theme() const {
    return value("System/Theme", "dark");
}

QString ConfigManager::language() const {
    return value("System/Language", "en");
}

void ConfigManager::setTheme(const QString& theme) {
    m_overrides["System/Theme"] = theme;
    if (m_settings) m_settings->setValue("System/Theme", theme);
}

void ConfigManager::setLanguage(const QString& lang) {
    m_overrides["System/Language"] = lang;
    if (m_settings) m_settings->setValue("System/Language", lang);
}

// ── Company / Invoice settings ────────────────────────────────────────────────
QString ConfigManager::companyName()      const { return value("Company/Name",      "DeliHub"); }
QString ConfigManager::companyAddress()   const { return value("Company/Address",   ""); }
QString ConfigManager::companyPhone()     const { return value("Company/Phone",     ""); }
QString ConfigManager::companyTaxNumber() const { return value("Company/TaxNumber", ""); }
QString ConfigManager::invoiceLogoPath()  const { return value("Company/LogoPath",  ""); }
int     ConfigManager::nextInvoiceNumber() const {
    bool ok; int n = value("Invoice/NextNumber", "1000").toInt(&ok);
    return ok ? n : 1000;
}
void ConfigManager::incrementInvoiceNumber() {
    int n = nextInvoiceNumber() + 1;
    m_overrides["Invoice/NextNumber"] = QString::number(n);
    if (m_settings) m_settings->setValue("Invoice/NextNumber", n);
}

// Tax settings
double ConfigManager::taxRate() const {
    QString val = value("Tax/Rate", "0");
    bool ok = false;
    double rate = val.toDouble(&ok);
    return ok ? rate : 0.0;
}
void ConfigManager::setTaxRate(double rate) {
    m_overrides["Tax/Rate"] = QString::number(rate, 'f', 2);
    if (m_settings) m_settings->setValue("Tax/Rate", rate);
}

void ConfigManager::setCompanyName(const QString& v)      { m_overrides["Company/Name"]      = v; if (m_settings) m_settings->setValue("Company/Name",      v); }
void ConfigManager::setCompanyAddress(const QString& v)   { m_overrides["Company/Address"]   = v; if (m_settings) m_settings->setValue("Company/Address",   v); }
void ConfigManager::setCompanyPhone(const QString& v)     { m_overrides["Company/Phone"]     = v; if (m_settings) m_settings->setValue("Company/Phone",     v); }
void ConfigManager::setCompanyTaxNumber(const QString& v) { m_overrides["Company/TaxNumber"] = v; if (m_settings) m_settings->setValue("Company/TaxNumber", v); }
void ConfigManager::setInvoiceLogoPath(const QString& v)  { m_overrides["Company/LogoPath"]  = v; if (m_settings) m_settings->setValue("Company/LogoPath",  v); }

// Auto-backup settings
QString ConfigManager::autoBackupTime()     const { return value("Backup/DailyTime",       "02:00"); }
QString ConfigManager::autoBackupDir()      const { return value("Backup/AutoDir",          ""); }
QString ConfigManager::lastAutoBackupDate() const { return value("Backup/LastAutoBackup",   ""); }
void ConfigManager::setLastAutoBackupDate(const QString& d) {
    m_overrides["Backup/LastAutoBackup"] = d;
    if (m_settings) m_settings->setValue("Backup/LastAutoBackup", d);
}
void ConfigManager::setAutoBackupTime(const QString& t) {
    m_overrides["Backup/DailyTime"] = t;
    if (m_settings) m_settings->setValue("Backup/DailyTime", t);
}
void ConfigManager::setAutoBackupDir(const QString& d) {
    m_overrides["Backup/AutoDir"] = d;
    if (m_settings) m_settings->setValue("Backup/AutoDir", d);
}

// ── Notes board background ────────────────────────────────────────────────────
QString ConfigManager::notesBgMode()      const { return value("Notes/BgMode",      "solid"); }
QString ConfigManager::notesBgImagePath() const { return value("Notes/BgImagePath", ""); }
void ConfigManager::setNotesBgMode(const QString& mode) {
    m_overrides["Notes/BgMode"] = mode;
    if (m_settings) m_settings->setValue("Notes/BgMode", mode);
}
void ConfigManager::setNotesBgImagePath(const QString& path) {
    m_overrides["Notes/BgImagePath"] = path;
    if (m_settings) m_settings->setValue("Notes/BgImagePath", path);
}

QString ConfigManager::receiptTemplateJson(int paperWidthMm) const {
    const QString key = QString("Receipt/Template_%1mm").arg(paperWidthMm <= 58 ? 58 : 80);
    return value(key, "");
}
void ConfigManager::setReceiptTemplateJson(int paperWidthMm, const QString& json) {
    const QString key = QString("Receipt/Template_%1mm").arg(paperWidthMm <= 58 ? 58 : 80);
    m_overrides[key] = json;
    if (m_settings) { m_settings->setValue(key, json); m_settings->sync(); }
}
int ConfigManager::receiptPaperWidthMm() const {
    bool ok = false;
    int mm = value("Receipt/PaperWidthMm", "80").toInt(&ok);
    return (ok && mm == 58) ? 58 : 80;
}
void ConfigManager::setReceiptPaperWidthMm(int mm) {
    const int clamped = (mm == 58) ? 58 : 80;
    m_overrides["Receipt/PaperWidthMm"] = QString::number(clamped);
    if (m_settings) m_settings->setValue("Receipt/PaperWidthMm", clamped);
}
QString ConfigManager::receiptPrinterName() const {
    return value("Receipt/PrinterName", "");
}
void ConfigManager::setReceiptPrinterName(const QString& name) {
    m_overrides["Receipt/PrinterName"] = name;
    if (m_settings) m_settings->setValue("Receipt/PrinterName", name);
}

bool ConfigManager::requireAuthForPOSDeletion() const {
    if (m_overrides.contains("requireAuthForPOSDeletion"))
        return m_overrides.value("requireAuthForPOSDeletion") == "true";
    if (m_settings)
        return m_settings->value("POS/requireAuthForDeletion", false).toBool();
    return false;
}

void ConfigManager::setRequireAuthForPOSDeletion(bool enabled) {
    m_overrides["requireAuthForPOSDeletion"] = enabled ? "true" : "false";
    if (m_settings) {
        m_settings->setValue("POS/requireAuthForDeletion", enabled);
        m_settings->sync();
    }
}
