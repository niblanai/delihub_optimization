# Receipt Designer — خطوات الدمج

## الملفات الجديدة
```
src/core/receipt_template.h / .cpp
src/ui/settings/receipt_designer_widget.h / .cpp
```

## الملفات المعدّلة (خد النسخة كاملة، مش diff)
```
src/services/receipt_printer.h / .cpp
src/infra/config_manager.h / .cpp
src/ui/settings/settings_page.h / .cpp
src/ui/pos/receipt_preview_dialog.h / .cpp
CMakeLists.txt
```

## افتراض واحد لازم تتأكد منه

`ReceiptPrinter::generatePreviewHtml()` بيستدعي الفانكشن الأصلية `renderBlock()`
بـ `Order{}` و `RegisterSession{}` افتراضيين (كائنات فاضية) للبلوكات اللي مش
محتاجة بيانات فاتورة حقيقية (Logo, CompanyName, Text, Divider...). ده معناه
إن `Order` و `RegisterSession` لازم يكون عندهم **default constructor** شغال
من غير ما يعمل crash. لو الكلاسين دول عندهم constructor بارامترات إجبارية،
قولي وأظبطها.

## ليه القرار ده بخصوص الـ plugins

رد الإيجنت اللي بعتهولي مقترح ١٢ ملف Plugin منفصل (كل واحد .h/.cpp) زي
`company_logo_plugin`, `barcode_plugin`, `text_plugin`... ده معماريّاً زيادة
عن اللزوم هنا: كل "plugin" في الحقيقة عبارة عن نوع + خصيتين أو تلاتة خواص،
ومفيهوش سلوك مختلف يستاهل كلاس منفصل (مفيش paintEvent، مفيش hit-testing،
مفيش state معقد). عملت بدالها **نموذج واحد** (`ReceiptBlock` = نوع +
`QVariantMap`) وسويتش واحد بيرندر كل نوع. النتيجة نفسها بالظبط من وجهة نظر
المستخدم — تضيف بلوك، تسحبه لمكانه، تعدّل خصائصه — لكن إضافة نوع بلوك تالت
عشرة بقى سطر `case` واحد بدل خمس ملفات جديدة.

## السحب والإفلات (Drag & Drop)

`QListWidget::InternalMove` هو drag & drop حقيقي من Qt — تقدر تمسك أي صف
وتسحبه لمكان تاني في القايمة، وده اللي بيحدد ترتيب البلوكات في الفاتورة.
مش Canvas حر بإحداثيات X/Y (الفاتورة الحرارية أصلاً عمودية بترتيب واحد، مفيش
داعي لحرية وضع ثنائية الأبعاد)، لكن التجربة هي نفسها: تسحب من الـ toolbox
(بالضغط على الزرار بيضيفه في الآخر) وترتّبه بالسحب.

## إصلاح مشكلة الباركود/التناسب في الصورة

المشكلة الأصلية: الباركود كان بيترسم بعرض ثابت `280px` من غير أي علاقة
بعرض الفاتورة، وجدول المنتجات مفهوش أعمدة بعرض محدد. دلوقتي كل بلوك بياخد
عرضه من `paperWidthMm` نفسه (عن طريق `renderCode128FitWidth`)، فالباركود
بيتمدد أو يصغر مع الورقة، ونفس المقاس اللي شايفه في المعاينة هو اللي هيتطبع.

`receipt_preview_dialog.cpp` بقى بيسحب القالب المحفوظ من `ConfigManager`
بدل الـ HTML الثابت القديم، فأي تعديل تعمله في الـ Designer بيظهر فوراً في
نافذة معاينة الفاتورة في الـ POS.

## اختيار الطابعة

`ReceiptPrinter::getAvailableThermalPrinters()` بيرجع كل الطابعات اللي
`QPrinterInfo` شايفها على الجهاز (مش فلترة بالاسم "thermal" لأن ده مش بيانات
موثوقة من النظام). اللي تختاره بيتحفظ في `ConfigManager::receiptPrinterName()`
ويتستخدم تلقائياً في الطباعة الفعلية من الـ POS ("Test Print" وزرار
"طباعة الفاتورة" في المعاينة). لو سايبها فاضية، هيطلعلك نافذة اختيار طابعة
عادية من الويندوز/النظام زي ما كانت شغالة قبل كده.
